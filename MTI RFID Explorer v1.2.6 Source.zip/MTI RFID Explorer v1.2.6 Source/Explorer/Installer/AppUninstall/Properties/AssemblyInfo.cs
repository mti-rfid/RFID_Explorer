﻿/*
 *****************************************************************************
 *                                                                           *
 *                   MTI CONFIDENTIAL AND PROPRIETARY                        *
 *                                                                           *
 * This source code is the sole property of MTI, Inc.  Reproduction or       *
 * utilization of this source code in whole or in part is forbidden without  *
 * the prior written consent of MTI, Inc.                                    *
 *                                                                           *
 * (c) Copyright MTI, Inc. 2011. All rights reserved.                        *
 *                                                                           *
 *****************************************************************************
 */

/*
 *****************************************************************************
 *
 * $Id: AssemblyInfo.cs,v 1.3 2009/12/12 00:58:31 dciampi Exp $
 * 
 * Description: 
 *
 *****************************************************************************
 */

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("AppUninstall")]
[assembly: AssemblyDescription("AppUninstall")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("MTI,Inc")]
[assembly: AssemblyProduct("AppUninstall")]
[assembly: AssemblyCopyright("Copyright 2011© MTI Inc. All Rights Reserved.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("fd93131c-88cd-4a32-0001-8a22cc63ebaa")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// [assembly: AssemblyVersion("0.0.0.0")]
// [assembly: AssemblyFileVersion("0.0.0.0")]
