#ifndef _CLS_INTERFACE
#define _CLS_INTERFACE




#include "Serial.h"
#include "UsbPort.h"


#endif